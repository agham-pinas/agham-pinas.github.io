import{c as a}from"../chunks/entry.CViP6SqT.js";export{a as start};
