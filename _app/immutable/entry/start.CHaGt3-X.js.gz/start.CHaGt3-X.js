import{c as a}from"../chunks/entry.CtoqcyZs.js";export{a as start};
